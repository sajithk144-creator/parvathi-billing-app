import 'package:flutter/material.dart';

void main() => runApp(const ParvathiApp());

const gold = Color(0xFFD6AD55);
const ink = Color(0xFF151515);

class ParvathiApp extends StatelessWidget {
  const ParvathiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PARVATHI BILLING',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: gold, brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF7F5F0),
        appBarTheme: const AppBarTheme(backgroundColor: ink, foregroundColor: gold),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class Product {
  Product(this.name, this.category, this.price, this.stock);
  final String name;
  final String category;
  final double price;
  int stock;
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final products = <Product>[
    Product('Cotton Shirt', 'Shirts', 499, 18),
    Product('Casual Sandal', 'Footwear', 399, 24),
    Product('Cotton Vest', 'Innerwear', 150, 30),
    Product('Dailywear', 'Dailywear', 250, 12),
  ];
  final cart = <Product, int>{};
  int tab = 0;

  double get total => cart.entries.fold(0, (sum, e) => sum + e.key.price * e.value);

  void add(Product p) {
    if (p.stock <= (cart[p] ?? 0)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Not enough stock')));
      return;
    }
    setState(() => cart[p] = (cart[p] ?? 0) + 1);
  }

  void finishBill() {
    if (cart.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Add products to the bill first')));
      return;
    }
    showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('Bill saved (demo)'),
      content: Text('PARVATHI FOOTWEAR & APPARELS\\nPALLOOR\\nPh: 9349959861\\n\\nTotal: ₹${total.toStringAsFixed(2)}\\n\\nConnect database and printer to enable permanent saving and printing.'),
      actions: [TextButton(onPressed: () {
        setState(() {
          for (final e in cart.entries) { e.key.stock -= e.value; }
          cart.clear();
        });
        Navigator.pop(context);
      }, child: const Text('Done'))],
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('PARVATHI', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 2)),
          Text('FOOTWEAR & APPARELS · PALLOOR', style: TextStyle(fontSize: 10, color: Colors.white70)),
        ]),
        actions: [IconButton(onPressed: () => setState(() => cart.clear()), icon: const Icon(Icons.delete_outline), tooltip: 'Clear bill')],
      ),
      body: tab == 0 ? billingView() : inventoryView(),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.receipt_long), label: 'Billing'),
          NavigationDestination(icon: Icon(Icons.inventory_2), label: 'Stock'),
        ],
      ),
    );
  }

  Widget billingView() => Column(children: [
    Container(
      width: double.infinity, color: ink, padding: const EdgeInsets.all(14),
      child: const Text('NEW BILL', style: TextStyle(color: gold, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
    ),
    Expanded(child: ListView(
      padding: const EdgeInsets.all(12),
      children: [
        const Text('Select products', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        ...products.map((p) => Card(child: ListTile(
          title: Text(p.name),
          subtitle: Text('${p.category}  ·  Stock: ${p.stock}  ·  ₹${p.price.toStringAsFixed(0)}'),
          trailing: IconButton(onPressed: () => add(p), icon: const Icon(Icons.add_circle, color: gold)),
        ))),
        const SizedBox(height: 12),
        const Text('Current bill', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        if (cart.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('No items added yet')),
        ...cart.entries.map((e) => ListTile(
          dense: true, title: Text(e.key.name), subtitle: Text('Qty: ${e.value}'),
          trailing: Text('₹${(e.key.price * e.value).toStringAsFixed(2)}'),
        )),
      ],
    )),
    Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
      decoration: const BoxDecoration(color: Colors.white, boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 8)]),
      child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('TOTAL', style: TextStyle(fontWeight: FontWeight.bold)),
          Text('₹${total.toStringAsFixed(2)}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        ]),
        const SizedBox(height: 10),
        SizedBox(width: double.infinity, child: FilledButton(
          style: FilledButton.styleFrom(backgroundColor: ink, foregroundColor: gold, padding: const EdgeInsets.all(14)),
          onPressed: finishBill, child: const Text('SAVE BILL'),
        )),
      ]),
    )
  ]);

  Widget inventoryView() => Column(children: [
    Container(width: double.infinity, color: ink, padding: const EdgeInsets.all(14),
      child: const Text('PRODUCT STOCK', style: TextStyle(color: gold, fontWeight: FontWeight.bold, letterSpacing: 1.5))),
    Expanded(child: ListView(padding: const EdgeInsets.all(12), children: products.map((p) => Card(
      child: ListTile(title: Text(p.name), subtitle: Text(p.category), trailing: Text('${p.stock} in stock')),
    )).toList())),
    const Padding(padding: EdgeInsets.all(12), child: Text('Demo inventory only. Online sync, barcode scanning, size/colour variants and staff permissions are not connected yet.', style: TextStyle(color: Colors.black54))),
  ]);
}
