# PARVATHI BILLING — Android starter

Shop receipt identity:
- PARVATHI FOOTWEAR & APPARELS
- PALLOOR
- Phone: 9349959861

## Included in this starter
- Flutter Android project structure
- Black and gold branded interface
- Billing screen with sample products
- Demo cart and total calculation
- Demo stock screen

## Important status
This is starter source code, not an installable APK. Bills and inventory are held only in app memory in this demo. Do not use it for live shop billing yet.

## Build on a computer with Flutter installed
1. Install Flutter SDK and Android Studio.
2. Open this project folder in Android Studio or VS Code.
3. Run `flutter pub get`.
4. Run `flutter run` on an Android device or emulator.
5. To create an APK, run `flutter build apk --release`.

## Still required before real shop use
- Supabase project and secure owner/staff authentication
- Online product and bill database
- Product size/colour variants and stock movements
- Barcode scanning and manual lookup
- Bluetooth 58mm ESC/POS printer integration
- PDF/Excel reports, backups and permission testing
- Testing on the actual phone and printer

Never put database secret/service-role keys inside the Android app.

## Build APK using a cloud runner (phone-only workflow)
This repository includes a GitHub Actions workflow at `.github/workflows/android-apk.yml`.
1. Create a GitHub repository and upload the project files (including the hidden `.github` folder).
2. Open the repository's **Actions** tab.
3. Select **Build Android APK** and tap **Run workflow**.
4. When the workflow completes, open its run page and download the `parvathi-billing-demo-apk` artifact.
5. Extract the ZIP and install the APK on a test Android phone.

This cloud workflow builds the current demo app only. It does not add cloud database, real barcode scanning, Bluetooth receipt printing, or full staff permissions. Those features need implementation and device testing before shop use.
